from colorama import Fore, Style

class ControladorCalculadora:
    def __init__(self, modelo, vista):
        self.modelo = modelo
        self.vista = vista

    def ejecutar(self):
        while True:
            self.vista.menu()
            opcion = input(Fore.YELLOW + "Seleccione una opción: " + Style.RESET_ALL)
            match opcion:
                case '1':
                    n1, signo, n2 = self.vista.datos()
                    self.modelo.agregar_operacion(n1, signo, n2)
                    
                    id_operacion = self.modelo.ultimo_id()
                    while True:
                        if signo == "/":
                            resultado = n1 / n2
                            print(Fore.GREEN + f"El resultado es: {resultado}")
                            self.modelo.agregar_resultado(resultado)
    
                            id_resultado = self.modelo.ultimo_id()
                            self.modelo.op_re(id_operacion, id_resultado)
                            break
                        elif signo == "x":
                            resultado = n1 * n2
                            print(Fore.GREEN + f"El resultado es: {resultado}")
                            self.modelo.agregar_resultado(resultado)
    
                            id_resultado = self.modelo.ultimo_id()
                            self.modelo.op_re(id_operacion, id_resultado)
                            break
                        elif signo == "+":
                            resultado = n1 + n2
                            print(Fore.GREEN + f"El resultado es: {resultado}")
                            self.modelo.agregar_resultado(resultado)
    
                            id_resultado = self.modelo.ultimo_id()
                            self.modelo.op_re(id_operacion, id_resultado)
                            break
                        elif signo == "-":
                            resultado = n1 - n2
                            print(Fore.GREEN + f"El resultado es: {resultado}")
                            self.modelo.agregar_resultado(resultado)
    
                            id_resultado = self.modelo.ultimo_id()
                            self.modelo.op_re(id_operacion, id_resultado)
                            break
                        else:
                            print("Opción incorrecta")

                case '2':
                    operaciones = self.modelo.ver_historial()
                    self.vista.historial(operaciones) 
